package model;

public class DiceLogic {
	public void throwDice(Dice dice) {
		int index=(int)(Math.random()*6);

		int[] states=dice.getDiceStates();

		for(int i=0;i<states.length;i++) {
			if(states[i]==1) {
				states[i]=2;
			}
		}
		states[index]++;
		dice.setDiceStates(states);
		dice.setNowDice(index+1);
		dice.setCount(dice.getCount()+1);
	}
}


